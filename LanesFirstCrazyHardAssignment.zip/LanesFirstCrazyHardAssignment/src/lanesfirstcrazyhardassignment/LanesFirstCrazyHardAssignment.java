
package lanesfirstcrazyhardassignment;

import java.util.Scanner;
public class LanesFirstCrazyHardAssignment 
{

    public static void main(String[] args) 
    {
   Scanner kb = new Scanner(System.in); 
      
   String item1;
   String item2;
   String item3;
   String s1;
   double price1;
   double price2;
   double price3;
   double average;
   String peas = "peas";
   String Peas = "Peas";
   int amount;
    double sum = 0;
    int notworking = 0;
   
   System.out.println("How Many Items");
   amount = kb.nextInt();
   
   String items[];
   items = new String[amount];
   double money[];
   money = new double[amount];
        
   
   for (int i=0;i<amount;i++)
   {
       System.out.println("Enter Item");
       items[i] = kb.next();
       System.out.println("Enter Price");  
       money[i] = kb.nextDouble();
   }
   for (int i=0; i<amount;i++)
   {
        sum = sum + money[i];
   }
   sum = sum/amount;
   for(int i=amount-1;i>=0;i--)
   {
    System.out.println("The Item is " + items[i] + " and costs " + money[i]);   
   }
     
   for(int i=0;i<amount;i++)
   {
   if(items[i].equals(peas)||items[i].equals(Peas))
   {
   notworking = 5;
   }
   }
   if (notworking > 4)
   {
        System.out.println("The Average Price Is " + sum);  
   }
    else {
       System.out.println("No Average Output");
   }
  /*
 System.out.println("Enter First Item");
 item1 = kb.next();
 System.out.println("Enter First Price");       
 price1 = kb.nextDouble();
 System.out.println("Enter Second Item");
 item2 = kb.next();
 System.out.println("Enter Second Price");       
 price2 = kb.nextDouble();
  System.out.println("Enter Third Item");
 item3 = kb.next();
 System.out.println("Enter Third Price");       
 price3 = kb.nextDouble();       
        
 average = (price1+price2+price3)/3;
 if (item1.equals(peas)||item2.equals(peas)||item3.equals(peas)||item1.equals(Peas)||item2.equals(Peas)||item3.equals(Peas))
 {
 System.out.println("The First Item is " + item1 + " and costs " + price1);
  System.out.println("The Second Item is " + item2 + " and costs " + price2);       
  System.out.println("The Third Item is " + item3 + " and costs " + price3);       
  System.out.println("The average of the prices is " + average);       
 }      
 else
     System.out.println("no average cost");
        */
    }
    
}

